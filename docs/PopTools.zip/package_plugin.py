# -*- coding: utf-8 -*-
import os
import zipfile
import hashlib
import json
import re
import shutil
from datetime import datetime

def package_plugin():
    # 设置路径
    base_dir = r'c:\Users\t7597\AppData\Roaming\Blender Foundation\Blender\4.2\scripts\addons\PopTools'
    packages_dir = os.path.join(base_dir, 'packages')
    docs_dir = os.path.join(base_dir, 'docs')
    
    # 确保目录存在
    os.makedirs(packages_dir, exist_ok=True)
    os.makedirs(docs_dir, exist_ok=True)
    
    # 读取blender_manifest.toml文件
    manifest_path = os.path.join(base_dir, 'blender_manifest.toml')
    with open(manifest_path, 'r', encoding='utf-8') as f:
        manifest_content = f.read()
    
    # 解析manifest信息
    version_match = re.search(r'version = "([^"]+)"', manifest_content)
    name_match = re.search(r'name = "([^"]+)"', manifest_content)
    tagline_match = re.search(r'tagline = "([^"]+)"', manifest_content)
    maintainer_match = re.search(r'maintainer = "([^"]+)"', manifest_content)
    website_match = re.search(r'website = "([^"]+)"', manifest_content)
    blender_version_match = re.search(r'blender_version_min = "([^"]+)"', manifest_content)
    
    version = version_match.group(1) if version_match else '3.1.3'
    name = name_match.group(1) if name_match else 'PopTools'
    tagline = tagline_match.group(1) if tagline_match else '蜂鸟工具箱'
    maintainer = maintainer_match.group(1) if maintainer_match else 'johnYancg94'
    website = website_match.group(1) if website_match else 'https://github.com/johnYancg94/PopTools'
    blender_version = blender_version_match.group(1) if blender_version_match else '4.2.0'
    
    # 创建zip文件
    zip_path = os.path.join(packages_dir, 'PopTools.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            # 排除不需要的目录
            dirs[:] = [d for d in dirs if d not in ['__pycache__', '.git', 'packages', 'docs']]
            
            for file in files:
                if file.endswith(('.py', '.toml', '.md')):
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, base_dir)
                    zipf.write(file_path, arcname)
    
    # 计算SHA256哈希
    with open(zip_path, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    
    print(f'ZIP文件已创建: {zip_path}')
    print(f'文件大小: {os.path.getsize(zip_path)} bytes')
    print(f'SHA256: {file_hash}')
    
    # 创建index.json
    index_data = {
        'version': '1',
        'timestamp': datetime.now().isoformat(),
        'extensions': [
            {
                'id': 'poptools',
                'version': version,
                'name': name,
                'tagline': tagline,
                'maintainer': maintainer,
                'type': 'add-on',
                'website': website,
                'blender_version_min': blender_version,
                'archive_url': './PopTools.zip',
                'archive_hash': f'sha256:{file_hash}',
                'archive_size': os.path.getsize(zip_path)
            }
        ]
    }
    
    index_json_path = os.path.join(packages_dir, 'index.json')
    with open(index_json_path, 'w', encoding='utf-8') as f:
        json.dump(index_data, f, ensure_ascii=False, indent=2)
    
    print(f'index.json已创建: {index_json_path}')
    
    # 读取README.md获取更新日志
    readme_path = os.path.join(base_dir, 'README.md')
    with open(readme_path, 'r', encoding='utf-8') as f:
        readme_content = f.read()
    
    # 提取3.1.3版本的更新日志
    changelog_match = re.search(r'### 3\.1\.3 \(2025\)\n(.*?)\n\n### 3\.1\.2', readme_content, re.DOTALL)
    changelog = changelog_match.group(1).strip() if changelog_match else '- 海岛配方道具智能重命名功能优化'
    
    # 创建index.html
    html_content = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{name} - Blender扩展</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            line-height: 1.6;
            color: #333;
        }}
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
        }}
        .version {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #007bff;
        }}
        .download-btn {{
            display: inline-block;
            background: #28a745;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 10px 0;
        }}
        .download-btn:hover {{
            background: #218838;
        }}
        .changelog {{
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .meta {{
            color: #666;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{name}</h1>
        <p>{tagline}</p>
        <p class="meta">版本 {version} | 维护者: {maintainer}</p>
    </div>
    
    <div class="version">
        <h2>📦 下载安装</h2>
        <p><strong>当前版本:</strong> {version}</p>
        <p><strong>支持Blender:</strong> {blender_version}+</p>
        <a href="./PopTools.zip" class="download-btn">下载 PopTools.zip</a>
        <p class="meta">文件大小: {os.path.getsize(zip_path)} bytes | SHA256: {file_hash[:16]}...</p>
    </div>
    
    <div class="changelog">
        <h2>🚀 版本 {version} 更新内容</h2>
        <div>
{chr(10).join([f'            <p>{line.strip()}</p>' for line in changelog.split(chr(10)) if line.strip()])}
        </div>
    </div>
    
    <div class="changelog">
        <h2>📋 安装说明</h2>
        <ol>
            <li>下载上方的 PopTools.zip 文件</li>
            <li>在Blender中进入 编辑 > 偏好设置 > 扩展</li>
            <li>点击右上角的下拉菜单，选择"从磁盘安装"</li>
            <li>选择下载的zip文件进行安装</li>
            <li>启用插件并保存偏好设置</li>
        </ol>
    </div>
    
    <div class="changelog">
        <h2>🔗 相关链接</h2>
        <p><a href="{website}">GitHub仓库</a> | <a href="./index.json">扩展信息(JSON)</a></p>
    </div>
    
    <footer style="text-align: center; margin-top: 40px; color: #666;">
        <p>© 2025 {maintainer}. 最后更新: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    </footer>
</body>
</html>'''
    
    index_html_path = os.path.join(packages_dir, 'index.html')
    with open(index_html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f'index.html已创建: {index_html_path}')
    
    # 移动文件到docs目录
    # 移动zip文件
    zip_dest = os.path.join(docs_dir, 'PopTools.zip')
    if os.path.exists(zip_dest):
        os.remove(zip_dest)
    shutil.move(zip_path, zip_dest)
    print(f'PopTools.zip已移动到: {zip_dest}')
    
    # 移动json文件
    json_dest = os.path.join(docs_dir, 'index.json')
    if os.path.exists(json_dest):
        os.remove(json_dest)
    shutil.move(index_json_path, json_dest)
    print(f'index.json已移动到: {json_dest}')
    
    # 移动html文件
    html_dest = os.path.join(docs_dir, 'index.html')
    if os.path.exists(html_dest):
        os.remove(html_dest)
    shutil.move(index_html_path, html_dest)
    print(f'index.html已移动到: {html_dest}')
    
    print('\n✅ 插件打包完成！所有文件已生成到docs目录中。')

if __name__ == '__main__':
    package_plugin()